import {
  setApiKey, getApiKey,
  searchPerson, getPersonDetails,
  getPersonMovieCredits, getPersonTVCredits,
  getMovieCredits, getTVCredits,
  getMovieDetails, getTVDetails,
  profileUrl, posterUrl, backdropUrl
} from './api.js';

// ── DOM refs ──────────────────────────────────
const apiKeyPrompt  = document.getElementById('apiKeyPrompt');
const apiKeyInput   = document.getElementById('apiKeyInput');
const saveApiKeyBtn = document.getElementById('saveApiKey');
const searchWrapper = document.getElementById('searchWrapper');
const searchInput   = document.getElementById('searchInput');
const searchSpinner = document.getElementById('searchSpinner');
const searchResults = document.getElementById('searchResults');
const suggestions   = document.getElementById('suggestions');
const landingState  = document.getElementById('landingState');
const actorBanner   = document.getElementById('actorBanner');
const bannerAvatar  = document.getElementById('bannerAvatar');
const bannerName    = document.getElementById('bannerName');
const bannerDetails = document.getElementById('bannerDetails');
const bannerTopMovies = document.getElementById('bannerTopMovies');
const bannerBio     = document.getElementById('bannerBio');
const backBtn       = document.getElementById('backBtn');
const loadingSection = document.getElementById('loadingSection');
const loadingText   = document.getElementById('loadingText');
const progressFill  = document.getElementById('progressFill');
const collabSection = document.getElementById('collabSection');
const collabTitle   = document.getElementById('collabTitle');
const collabGrid    = document.getElementById('collabGrid');
const errorToast    = document.getElementById('errorToast');
const movieModal    = document.getElementById('movieModal');
const modalClose    = document.getElementById('modalClose');
const modalBackdrop = document.getElementById('modalBackdrop');
const modalPoster   = document.getElementById('modalPoster');
const modalTitle    = document.getElementById('modalTitle');
const modalMeta     = document.getElementById('modalMeta');
const modalOverview = document.getElementById('modalOverview');
const modalCast     = document.getElementById('modalCast');

// ── Reveal animations ─────────────────────────
/**
 * Trigger entrance animation on a single element.
 * @param {HTMLElement} el
 * @param {number} delay - ms delay before animation starts
 */
function revealElement(el, delay = 0) {
  el.style.animationDelay = delay + 'ms';
  el.classList.add('revealed');
}

/**
 * Trigger entrance animations on a list of elements with staggered delay.
 * @param {NodeList|Array} els
 * @param {number} baseDelay - initial ms delay
 * @param {number} stagger - ms between each element
 */
function revealElements(els, baseDelay = 0, stagger = 80) {
  els.forEach((el, i) => {
    revealElement(el, baseDelay + i * stagger);
  });
}

// ── State ─────────────────────────────────────
let searchTimer = null;
let currentActor = null;
let currentCollabs = null;

// ── Cache ─────────────────────────────────────
const creditsCache = new Map();    // key: "movie-123" or "tv-456" → cast[]
const collabCache = new Map();     // key: actorId → collab results
const searchCache = new Map();     // key: query → search results (avoids redundant API calls)

// ── API Key ───────────────────────────────────
// Restore saved key from localStorage on load
const savedKey = localStorage.getItem('tmdb_api_key');
if (savedKey) {
  setApiKey(savedKey);
}

if (getApiKey()) {
  showApp();
}

saveApiKeyBtn.addEventListener('click', () => {
  const key = apiKeyInput.value.trim();
  if (!key) return;
  setApiKey(key);
  showApp();
});

apiKeyInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveApiKeyBtn.click();
});

function showApp() {
  apiKeyPrompt.classList.remove('show');
  searchWrapper.classList.remove('hidden');
  suggestions.classList.remove('hidden');
  landingState.classList.remove('hidden');

  // Trigger staggered entrance animations for suggestion chips
  const chips = suggestions.querySelectorAll('.suggestion-chip');
  revealElements(chips, 200, 60);
}

// ── Toast ─────────────────────────────────────
let toastTimer;
function showToast(msg) {
  clearTimeout(toastTimer);
  errorToast.textContent = msg;
  errorToast.classList.add('show');
  toastTimer = setTimeout(() => errorToast.classList.remove('show'), 3000);
}

// ── Search ────────────────────────────────────
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  const query = searchInput.value.trim();

  if (!query) {
    searchResults.classList.remove('show');
    searchSpinner.classList.remove('active');
    return;
  }

  // Hide previous results while searching
  actorBanner.classList.remove('show');
  collabSection.classList.remove('show');
  loadingSection.classList.remove('show');
  landingState.classList.add('hidden');

  searchSpinner.classList.add('active');
  searchTimer = setTimeout(() => doSearch(query), 300);
});

function doSearch(query) {
  // Check cache first
  const cached = searchCache.get(query);
  if (cached) {
    searchSpinner.classList.remove('active');
    renderSearchResults(cached);
    return;
  }

  searchPerson(query)
    .then(results => {
      searchSpinner.classList.remove('active');
      searchCache.set(query, results);
      renderSearchResults(results);
    })
    .catch(err => {
      searchSpinner.classList.remove('active');
      if (err.message === 'INVALID_API_KEY') {
        showToast('API Key 无效，请重新输入');
        resetApiKey();
      } else if (err.message === 'RATE_LIMITED') {
        showToast('请求太频繁，请稍等再试');
      } else {
        showToast('搜索失败，请检查网络连接');
      }
    });
}

// ── Search keyboard navigation ────────────────
let searchResultIndex = -1;
searchInput.addEventListener('keydown', (e) => {
  const items = searchResults.querySelectorAll('.search-result-item');
  if (!items.length) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    searchResultIndex = Math.min(searchResultIndex + 1, items.length - 1);
    updateActiveItem(items);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    searchResultIndex = Math.max(searchResultIndex - 1, 0);
    updateActiveItem(items);
  } else if (e.key === 'Enter' && searchResultIndex >= 0) {
    e.preventDefault();
    items[searchResultIndex].click();
  }
});

function updateActiveItem(items) {
  items.forEach((item, i) => {
    item.classList.toggle('active', i === searchResultIndex);
  });
  items[searchResultIndex]?.scrollIntoView({ block: 'nearest' });
}

function renderSearchResults(results) {
  searchResults.innerHTML = '';
  searchResultIndex = -1;

  if (!results.length) {
    searchResults.innerHTML = '<div class="search-empty">未找到匹配的演员</div>';
    searchResults.classList.add('show');
    return;
  }

  const sliced = results.slice(0, 8);
  sliced.forEach(person => {
    const div = document.createElement('div');
    div.className = 'search-result-item';
    const knownFor = (person.known_for || []).slice(0, 3).map(m => m.title || m.name).join(', ');
    div.innerHTML = `
      ${person.profile_path
        ? `<img src="${profileUrl(person.profile_path)}" alt="" loading="lazy">`
        : `<div class="no-avatar">🎬</div>`
      }
      <div class="info">
        <h3>${esc(person.name)}</h3>
        <span>${person.known_for_department || ''}${knownFor ? ' · ' + knownFor : ''}</span>
      </div>
    `;
    div.addEventListener('click', () => selectActor(person));
    searchResults.appendChild(div);
  });

  searchResults.classList.add('show');
}

// ── Quick suggestions ─────────────────────────
suggestions.addEventListener('click', (e) => {
  const chip = e.target.closest('.suggestion-chip');
  if (!chip) return;
  const name = chip.dataset.name;
  searchInput.value = name;
  searchResults.classList.remove('show');
  landingState.classList.add('hidden');
  // Show spinner immediately for responsiveness
  searchSpinner.classList.add('active');
  doSearch(name);
});

// ── Actor Selection ───────────────────────────
async function selectActor(person) {
  currentActor = person;
  searchResults.classList.remove('show');
  searchInput.value = '';
  searchResultIndex = -1;

  // Show banner immediately with what we have (guard against missing profile)
  bannerAvatar.src = person.profile_path ? profileUrl(person.profile_path) : '';
  bannerAvatar.alt = person.name || '';
  bannerName.textContent = person.name || '';
  bannerDetails.textContent = person.known_for_department || '';
  bannerTopMovies.innerHTML = '';
  actorBanner.classList.add('show');
  landingState.classList.add('hidden');

  // Show loading
  collabSection.classList.remove('show');
  loadingSection.classList.add('show');
  loadingText.textContent = '正在加载作品列表...';
  progressFill.style.width = '0%';

  try {
    const [details, movieCredits, tvCredits] = await Promise.all([
      getPersonDetails(person.id),
      getPersonMovieCredits(person.id),
      getPersonTVCredits(person.id)
    ]);

    // Update banner with details + top 5 movies
    bannerDetails.textContent = [
      details.birthday ? `🎂 ${details.birthday}` : '',
      details.place_of_birth ? `📍 ${details.place_of_birth}` : '',
    ].filter(Boolean).join('  ·  ') || person.known_for_department || '';
    bannerBio.textContent = details.biography
      ? details.biography.slice(0, 150).replace(/\n/g, ' ') + (details.biography.length > 150 ? '…' : '')
      : '';

    const allCredits = [
      ...movieCredits.map(m => ({ id: m.id, type: 'movie', title: m.title || m.original_title, date: m.release_date || '', popularity: m.popularity, poster_path: m.poster_path })),
      ...tvCredits.map(t => ({ id: t.id, type: 'tv', title: t.name || t.original_name, date: t.first_air_date || '', popularity: t.popularity, poster_path: t.poster_path }))
    ];

    const seenWorks = new Set();
    const uniqueCredits = [];
    for (const w of allCredits) {
      const k = `${w.type}-${w.id}`;
      if (seenWorks.has(k)) continue;
      seenWorks.add(k);
      uniqueCredits.push(w);
    }

    // Banner top 5: sort by box office revenue (fetch details for top popular movies)
    const moviesOnly = uniqueCredits.filter(w => w.type === 'movie');
    const topPopular = [...moviesOnly].sort((a, b) => b.popularity - a.popularity).slice(0, 15);
    const movieDetails = await Promise.allSettled(
      topPopular.map(w => getMovieDetails(w.id))
    );
    const withRevenue = topPopular
      .map((w, i) => ({ ...w, revenue: movieDetails[i].status === 'fulfilled' ? (movieDetails[i].value.revenue || 0) : 0 }))
      .sort((a, b) => b.revenue - a.revenue);
    const top5 = withRevenue.slice(0, 5);

    bannerTopMovies.innerHTML = top5.map(w => `
      <div class="top-movie-item">
        ${w.poster_path
          ? `<img src="${posterUrl(w.poster_path, 'w92')}" alt="${esc(w.title)}" loading="lazy" data-movie-type="${w.type}" data-movie-id="${w.id}">`
          : `<div class="top-movie-placeholder" data-movie-type="${w.type}" data-movie-id="${w.id}">${esc(w.title)}</div>`
        }
        <div class="t-label">${esc(w.title)}</div>
        <div class="t-revenue">${w.revenue ? '$' + fmtMoney(w.revenue) : ''} · ${w.date.slice(0,4) || '—'}</div>
      </div>`).join('');

    // Compute collaborations: sort by date DESC (newest first) to cover full career
    let collabs;
    if (collabCache.has(person.id)) {
      collabs = collabCache.get(person.id);
      loadingSection.classList.remove('show');
    } else {
      const creditsByDate = [...uniqueCredits].sort((a, b) => b.date.localeCompare(a.date));
      collabs = await computeCollaborations(person.id, creditsByDate);
      collabCache.set(person.id, collabs);
    }
    currentCollabs = collabs;
    renderCollaborations(collabs, person.name);

  } catch (err) {
    loadingSection.classList.remove('show');
    if (err.message === 'INVALID_API_KEY') {
      showToast('API Key 无效，请重新输入');
      resetApiKey();
    } else {
      showToast('加载失败: ' + err.message);
    }
  }
}

// ── Collaboration Computation ─────────────────
async function computeCollaborations(actorId, sortedWorks) {
  // sortedWorks is pre-sorted by date DESC, already deduplicated
  // Uniform sampling across the career to cover ALL eras (not just recent)
  const MAX = 50;
  let sampledWorks;
  if (sortedWorks.length <= MAX) {
    sampledWorks = sortedWorks;
  } else {
    const step = sortedWorks.length / MAX;
    sampledWorks = [];
    for (let i = 0; i < MAX; i++) {
      sampledWorks.push(sortedWorks[Math.floor(i * step)]);
    }
  }
  const total = sampledWorks.length;

  const collabMap = new Map();

  loadingText.textContent = `正在分析 ${total} 部作品中的合作演员...`;

  const BATCH = 8;
  for (let i = 0; i < sampledWorks.length; i += BATCH) {
    const batch = sampledWorks.slice(i, i + BATCH);
    const results = await Promise.allSettled(
      batch.map(w => {
        const cacheKey = `${w.type}-${w.id}`;
        if (creditsCache.has(cacheKey)) {
          return Promise.resolve(creditsCache.get(cacheKey));
        }
        return (w.type === 'movie' ? getMovieCredits(w.id) : getTVCredits(w.id))
          .then(cast => { creditsCache.set(cacheKey, cast); return cast; });
      })
    );

    results.forEach((r, j) => {
      if (r.status !== 'fulfilled') return;
      const work = batch[j];
      for (const castMember of r.value) {
        if (castMember.id === actorId) continue;
        const name = castMember.name;
        if (!collabMap.has(name)) {
          collabMap.set(name, {
            id: castMember.id,
            name,
            profile_path: castMember.profile_path,
            count: 0,
            sharedWorks: new Map()
          });
        }
        const entry = collabMap.get(name);
        entry.count++;
        const swKey = `${work.type}-${work.id}`;
        if (!entry.sharedWorks.has(swKey)) {
          entry.sharedWorks.set(swKey, work);
        }
      }
    });

    const done = Math.min(i + BATCH, total);
    progressFill.style.width = `${(done / total) * 100}%`;
    loadingText.textContent = `正在分析 ${done}/${total} 部作品...`;
  }

  // Sort by count desc, take top 50, convert sharedWorks to sorted array (top 5)
  return [...collabMap.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, 50)
    .map(c => ({
      ...c,
      sharedWorks: [...c.sharedWorks.values()]
        .sort((a, b) => b.popularity - a.popularity)
        .slice(0, 5)
    }));
}

/**
 * Build mini poster rows HTML for shared movies.
 */
function buildMoviePostersHTML(sharedWorks) {
  if (!sharedWorks || sharedWorks.length === 0) return '';
  return sharedWorks.map(w => {
    const revenue = w.revenue ? '$' + fmtMoney(w.revenue) : '';
    const year = w.date ? w.date.slice(0, 4) : '';
    const displayTitle = w.title.length > 12 ? w.title.slice(0, 12) + '…' : w.title;
    return `
      <div class="movie-poster-item" data-movie-type="${w.type}" data-movie-id="${w.id}">
        ${w.poster_path
          ? `<img class="mp-thumb" src="${posterUrl(w.poster_path, 'w92')}" alt="${esc(w.title)}" loading="lazy">`
          : `<div class="mp-thumb-placeholder">🎬</div>`
        }
        <div class="mp-info">
          <div class="mp-title">${esc(displayTitle)}</div>
          <div class="mp-meta">${year}</div>
        </div>
        ${revenue ? `<span class="mp-revenue">${revenue}</span>` : ''}
      </div>
    `;
  }).join('');
}

// ── Render Collaborations ─────────────────────
function renderCollaborations(collabs, actorName) {
  loadingSection.classList.remove('show');
  collabGrid.innerHTML = '';

  if (!collabs.length) {
    collabGrid.innerHTML = '<p class="collab-empty">未找到合作演员数据</p>';
    collabSection.classList.add('show');
    return;
  }

  collabTitle.innerHTML = `与 <strong>「${esc(actorName)}」</strong> 合作过的演员 · ${collabs.length} 人`;

  collabs.forEach(c => {
    const card = document.createElement('div');
    card.className = 'collab-card';

    const postersHTML = buildMoviePostersHTML(c.sharedWorks);

    card.innerHTML = `
      ${c.profile_path
        ? `<img class="avatar" src="${profileUrl(c.profile_path, 'w185')}" alt="${esc(c.name)}" loading="lazy">`
        : `<div class="no-avatar-card">🎬</div>`
      }
      <div class="meta">
        <h4>${esc(c.name)}</h4>
        <span class="count">合作 ${c.count} 次</span>
      </div>
      <div class="movie-posters-row">${postersHTML}</div>
    `;

    // Movie poster click → open movie detail
    card.querySelectorAll('.movie-poster-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const type = item.dataset.movieType;
        const id = parseInt(item.dataset.movieId);
        if (type && id) openMovieDetail(type, id);
      });
    });

    card.addEventListener('click', () => {
      selectActor({ id: c.id, name: c.name, profile_path: c.profile_path, known_for_department: '' });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    collabGrid.appendChild(card);
  });

  collabSection.classList.add('show');

  // Trigger staggered entrance animations for collab cards
  const cards = collabGrid.querySelectorAll('.collab-card');
  revealElements(cards, 80, 80);
}

// ── Back button ───────────────────────────────
backBtn.addEventListener('click', () => {
  currentActor = null; currentCollabs = null;
  actorBanner.classList.remove('show');
  collabSection.classList.remove('show');
  loadingSection.classList.remove('show');
  searchInput.value = '';
  landingState.classList.remove('hidden');
  searchInput.focus();
});

// ── Click outside search results ──────────────
document.addEventListener('click', (e) => {
  if (!searchResults.contains(e.target) && e.target !== searchInput) {
    searchResults.classList.remove('show');
  }

  // Movie poster/placeholder click → open detail modal
  const movieThumb = e.target.closest('[data-movie-type]');
  if (movieThumb) {
    const type = movieThumb.dataset.movieType;
    const id = parseInt(movieThumb.dataset.movieId);
    if (type && id) openMovieDetail(type, id);
  }
});

// ── Movie Detail Modal ────────────────────────
modalClose.addEventListener('click', closeModal);
movieModal.addEventListener('click', (e) => {
  if (e.target === movieModal) closeModal();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

function closeModal() {
  movieModal.classList.remove('show');
  document.body.style.overflow = '';
}

// Use event delegation for modal cast clicks (fixes memory leak from per-element listeners)
modalCast.addEventListener('click', (e) => {
  const chip = e.target.closest('.modal-cast-chip');
  if (!chip) return;
  const pid = parseInt(chip.dataset.personId);
  const pname = chip.dataset.personName;
  const pprofile = chip.dataset.personProfile;
  closeModal();
  selectActor({ id: pid, name: pname, profile_path: pprofile, known_for_department: '' });
});

async function openMovieDetail(type, id) {
  movieModal.classList.add('show');
  document.body.style.overflow = 'hidden';

  // Show loading
  modalBackdrop.style.backgroundImage = '';
  modalPoster.src = '';
  modalTitle.textContent = '加载中...';
  modalMeta.innerHTML = '';
  modalOverview.textContent = '';
  modalCast.innerHTML = '<div class="modal-loading">正在加载...</div>';

  try {
    const [details, credits] = await Promise.all([
      type === 'movie' ? getMovieDetails(id) : getTVDetails(id),
      (async () => {
        const cacheKey = `${type}-${id}`;
        if (creditsCache.has(cacheKey)) return creditsCache.get(cacheKey);
        const cast = type === 'movie' ? await getMovieCredits(id) : await getTVCredits(id);
        creditsCache.set(cacheKey, cast);
        return cast;
      })()
    ]);

    // Backdrop
    if (details.backdrop_path) {
      modalBackdrop.style.backgroundImage = `url(${backdropUrl(details.backdrop_path)})`;
    }

    // Poster
    modalPoster.src = posterUrl(details.poster_path, 'w342');

    // Title
    modalTitle.textContent = details.title || details.name || '';

    // Meta
    const year = (details.release_date || details.first_air_date || '').slice(0, 4);
    const runtime = details.runtime ? `${details.runtime}分钟` : '';
    const genres = (details.genres || []).map(g => g.name).join(' / ');
    const rating = details.vote_average ? `★ ${details.vote_average.toFixed(1)}` : '';
    modalMeta.innerHTML = [year, runtime, genres, rating].filter(Boolean).map(s => `<span>${s}</span>`).join('');

    // Overview
    modalOverview.textContent = details.overview || '暂无简介';

    // Cast
    const topCast = (credits || []).slice(0, 30);
    modalCast.innerHTML = topCast.map(c => `
      <div class="modal-cast-chip" data-person-id="${c.id}" data-person-name="${esc(c.name)}" data-person-profile="${c.profile_path || ''}">
        ${c.profile_path
          ? `<img src="${profileUrl(c.profile_path)}" alt="${esc(c.name)}" loading="lazy">`
          : `<div class="no-avatar-small">🎬</div>`
        }
        <span class="cast-name">${esc(c.name)}</span>
        ${c.character ? `<span class="cast-role">${esc(c.character)}</span>` : ''}
      </div>
    `).join('');

  } catch (err) {
    modalCast.innerHTML = '<div class="modal-loading">加载失败</div>';
    showToast('加载电影详情失败');
  }
}

// ── Utils ─────────────────────────────────────
function esc(str) {
  if (str == null) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function resetApiKey() {
  localStorage.removeItem('tmdb_api_key');
  setApiKey('');
  apiKeyPrompt.classList.add('show');
  searchWrapper.classList.add('hidden');
  suggestions.classList.add('hidden');
  landingState.classList.add('hidden');
  actorBanner.classList.remove('show');
  collabSection.classList.remove('show');
  loadingSection.classList.remove('show');
}

// ── fmtMoney ──────────────────────────────────
function fmtMoney(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(0) + 'M';
  return n.toString();
}
