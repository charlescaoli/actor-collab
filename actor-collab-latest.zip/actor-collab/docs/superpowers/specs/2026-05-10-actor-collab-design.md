# Actor Collab 视觉 & UX 重设计规范

**版本：** v1.0
**日期：** 2026-05-10
**状态：** 已批准
**方向：** Modern Blockbuster · 戏剧张力动效

---

## 1. 设计愿景

将 Actor Collab 从"功能型深色应用"升级为"具有现代大片质感的产品级界面"。核心关键词：**对比、层次、节奏、期待感**。每一个交互都有目的，每一次动效都有叙事感。

---

## 2. 字体系统

### 2.1 字体选择

| 用途 | 字体 | 权重 | 说明 |
|------|------|------|------|
| Logo / 标题 | `Playfair Display` (serif) | 700 | 有电影标题的优雅大气感 |
| 演员英文名 | `Playfair Display` (italic) | 400 | 斜体增加灵动 |
| 正文 / UI | `DM Sans` | 400/500/600/700 | 几何无衬线，现代清晰 |
| 中文回退 | `思源黑体` / `Noto Sans SC` | — | 保持可读性 |

### 2.2 字体应用规则

```css
h1, h2, h3 { font-family: 'Playfair Display', serif; font-weight: 700; }
.actor-name, .modal-title { font-family: 'Playfair Display', serif; }
body, p, span, button { font-family: 'DM Sans', sans-serif; }
```

### 2.3 字号规范

| 元素 | 字号 |
|------|------|
| Logo 标题 | 2.4rem (38px) |
| 演员名字 | 1.5rem (24px) |
| 模态框标题 | 1.3rem (21px) |
| 卡片标题 | 0.88rem (14px) |
| 正文 | 0.88rem (14px) |
| 次要文字 | 0.8rem (13px) |
| 小标签 | 0.72rem (12px) |
| 极小标签 | 0.68rem (11px) |

---

## 3. 配色系统

### 3.1 色彩变量

```css
:root {
  --bg: #050508;                 /* 深黑背景 */
  --bg-deep: #030305;             /* 极致深色 */
  --card-bg: rgba(12, 12, 22, 0.92); /* 深蓝黑卡片 */
  --text: #f0f0f4;               /* 主文字 */
  --text-secondary: #7a7a8c;      /* 次要文字 */
  --accent: #f5c518;             /* 金色强调 */
  --accent-dim: #b8930f;         /* 深金色 */
  --accent-glow: rgba(245, 197, 24, 0.2); /* 光晕 */
  --border: rgba(255, 255, 255, 0.06);    /* 默认边框 */
  --border-hover: rgba(245, 197, 24, 0.3); /* Hover 边框 */
  --radius: 14px;                /* 大圆角 */
  --radius-sm: 8px;              /* 小圆角 */
}
```

### 3.2 背景氛围

```css
body::before {
  /* 三层 radial gradient 光晕，模拟舞台灯光 */
  background:
    radial-gradient(ellipse at 30% 10%, rgba(245, 197, 24, 0.06) 0%, transparent 50%),
    radial-gradient(ellipse at 70% 30%, rgba(245, 197, 24, 0.04) 0%, transparent 40%),
    radial-gradient(ellipse at 50% 90%, rgba(100, 80, 200, 0.05) 0%, transparent 50%);
  animation: ambientPulse 12s ease-in-out infinite alternate;
}

body::after {
  /* 极低透明度胶片颗粒纹理 */
  opacity: 0.03;
  background-image: url("data:image/svg+xml,...");
}
```

---

## 4. 动效系统（核心）

### 4.1 哲学原则

**"戏剧张力" = 有节奏、有留白、有期待。**

- 每个元素的出现不是随机的，有编排
- 动效使用 `cubic-bezier(0.34, 1.56, 0.64, 1)` 弹性曲线
- 入场动画 stagger 延迟 50-100ms
- 关闭动画比打开动画快（150ms vs 300ms）

### 4.2 入场动画规范

页面加载时，各模块按 Z 轴顺序依次入场：

| 模块 | 延迟 | 动画 |
|------|------|------|
| Header | 0ms | 淡入 |
| 搜索框 | 100ms | 从下方滑入 + 弹性 |
| 快捷 Chips | 200-600ms | 依次弹性弹出 (stagger 60ms) |
| Landing 提示 | 250ms | 淡入 |
| 搜索结果 | 即时 | 逐项淡入上移 (stagger 50ms) |
| 演员 Banner | 300ms | 模糊→清晰过渡 |
| 协作者卡片 | 400-800ms | 依次淡入上移 (stagger 80ms) |
| 模态框内容 | 0ms | 从下方弹出 + 弹性 |

### 4.3 弹性曲线

```css
/* 戏剧张力曲线：快速启动 + 弹性过冲 + 平稳落地 */
--ease-dramatic: cubic-bezier(0.34, 1.56, 0.64, 1);

/* 快速退出曲线：比进入快 */
--ease-fast-out: cubic-bezier(0.4, 0, 1, 1);
```

### 4.4 各场景动效

#### 搜索框
- 聚焦：边框变金色 + 背景光晕扩散 (300ms ease-out)
- 输入时：右侧 spinner 显示

#### 快捷 Chips
- 入场：scale 0.8→1 + opacity 0→1，stagger 60ms
- Hover：`translateY(-2px) scale(1.02)` + 金色边框 + 光晕

#### 协作者卡片
- 入场：translateY(16px)→0 + opacity 0→1，stagger 80ms
- Hover：
  - `translateY(-6px) scale(1.02)` (主效果)
  - 边框渐变发光（`::before` 伪元素 + opacity 过渡）
  - `box-shadow: 0 16px 40px rgba(0,0,0,0.4), 0 0 30px rgba(245,197,24,0.1)`
  - 边框颜色变为 `rgba(245,197,24,0.2)`

#### 模态框
- 打开：背景淡入 + 内容从下方弹出 + 弹性过冲 (300ms ease-out)
- 关闭：快速淡出 (150ms ease-fast-out)
- 演员 cast chips Hover：`scale(1.05)`

#### 标题 Logo Shimmer
```css
background: linear-gradient(135deg, #f5c518 0%, #fff 35%, #f5c518 65%, #b8930f 100%);
background-size: 300% auto;
animation: cinematicShimmer 4s ease-in-out infinite alternate;
```

#### Loading 状态
- 胶片风格双环旋转加载图标
- 进度条：渐变流光动画

---

## 5. 组件规范

### 5.1 搜索框
- 高度：54px
- 圆角：12px
- 聚焦态：`border-color: var(--accent)` + `box-shadow: 0 0 0 3px rgba(245,197,24,0.1), 0 0 30px rgba(245,197,24,0.15)`
- 内图标：右侧搜索图标

### 5.2 快捷建议 Chips
- 内边距：8px 18px
- 圆角：24px（胶囊形）
- Hover：金色边框 + 文字变金色 + 光晕阴影

### 5.3 演员 Banner
- 布局：flex，横向排列
- 头像：100px × 150px，圆角 10px
- 按钮：
  - 返回按钮：ghost 风格（透明背景 + 边框）
  - 关系图按钮：实心金色渐变

### 5.4 协作者卡片
- 最小宽度：170px
- 封面图：`aspect-ratio: 2/3`
- Hover 边框：`::before` 伪元素 + 金色渐变边框（`border-image` 或 `background-clip` 技术）
- 共享电影行：左侧海报缩略图 + 年份 + 票房

### 5.5 电影模态框
- 最大宽度：720px，最大高度 90vh
- 英雄区：180px 高，背景渐变
- 海报：左侧 260px × 146px（横版）
- 演员表：横向滚动，72px 宽 chip

### 5.6 Loading 状态
- 加载图标：双环旋转（金色 + 深金色，反向）
- 进度条：渐变流光动画

---

## 6. 技术实现计划

### 6.1 文件修改清单

| 文件 | 修改内容 |
|------|----------|
| `css/style.css` | 重写设计系统（变量、字体、组件样式、动画） |
| `js/app.js` | 添加入场动画触发逻辑 |
| `index.html` | 引入 Google Fonts 链接 |

### 6.2 CSS 动画实现

所有入场动画通过 CSS `@keyframes` + `animation` + `animation-delay` 实现，不依赖 JavaScript 动画库。

```css
/* 入场关键帧 */
@keyframes sectionReveal {
  from { opacity: 0; transform: translateY(24px); }
  to { opacity: 1; transform: translateY(0); }
}

.section { animation: sectionReveal 0.6s var(--ease-dramatic) forwards; }
.section:nth-child(1) { animation-delay: 0.1s; }
.section:nth-child(2) { animation-delay: 0.2s; }
```

### 6.3 JavaScript 动态入场

对于非首屏渲染的元素（如搜索结果、协作者列表），通过 JS 添加 `.revealed` class 触发动画：

```javascript
function revealElement(el, delay = 0) {
  el.style.animationDelay = delay + 'ms';
  el.classList.add('revealed');
}
```

---

## 7. Mockup 参考

完整 Mockup 文件：`/design-mockup.html`

---

## 8. 验收标准

- [ ] Logo 标题有流光 Shimmer 动画
- [ ] 页面加载时各模块依次入场（可观察到的 stagger 效果）
- [ ] 搜索框聚焦时有金色光晕扩散效果
- [ ] 快捷建议 Chips 有弹性弹出动画
- [ ] 协作者卡片 Hover 有金色边框发光 + 上升效果
- [ ] 模态框打开有弹性动画，关闭比打开快
- [ ] 演员 Cast chips Hover 有放大效果
- [ ] Loading 状态有胶片风格双环动画 + 流光进度条
- [ ] 背景有微弱光晕脉动动画
- [ ] 整体色调统一为深黑 + 金色强调
- [ ] 字体为 Playfair Display（标题）+ DM Sans（正文）
- [ ] 移动端适配正常
